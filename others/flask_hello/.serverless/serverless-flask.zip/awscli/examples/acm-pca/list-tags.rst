**To list the tags for your certificate authority**

The ``list-tags`` command lists the tags associated with your private CA::

  aws acm-pca list-tags --certificate-authority-arn arn:aws:acm-pca:region:account:certificate-authority/123455678-1234-1234-1234-123456789012 --max-results 10