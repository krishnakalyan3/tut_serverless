# Simple Flask App

```
sudo pip3 install -r requirements.txt
python3 app.py
```
