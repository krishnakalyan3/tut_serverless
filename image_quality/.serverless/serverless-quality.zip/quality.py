import random


def lucky_number(event, context):
    print(event)
    print(context)

    return 'Hello World'